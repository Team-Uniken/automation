package com.uniken.rdna;

import java.util.Comparator;
import java.util.LinkedHashMap;

public abstract class RDNA{

	public static class RDNAStatus<T> {
		public int errorCode;
		public T result;

		public RDNAStatus(int errorCode, T result) {
			this.errorCode = errorCode;
			this.result = result;
		}
	}

	public enum RDNAMethodID {
		RDNA_METH_NONE(0),                                   /* Not a specific method ID     */
		RDNA_METH_INITIALIZE(1),                             /* Initialize runtime           */
		RDNA_METH_TERMINATE(2),                              /* Terminate runtime            */
		RDNA_METH_RESUME(3),                                 /* Resume runtime               */
		RDNA_METH_PAUSE(4),                                  /* Pause runtime                */
		RDNA_METH_GET_CONFIG(5),                             /* Get config call back method */
		RDNA_METH_CHECK_CHALLENGE(6),                        /* Check Challenge callback method*/
		RDNA_METH_UPDATE_CHALLENGE(7),                       /* Update challenge call back method*/
		RDNA_METH_GET_ALL_CHALLENGES(8),                     /* Get all Challenge callback method*/
		RDNA_METH_LOGOFF(9),                                 /* Log off call back method*/
		RDNA_METH_FORGOT_PASSWORD(10),                       /* Forgot password call back method*/
		RDNA_METH_GET_POST_LOGIN_CHALLENGES(11),
		RDNA_METH_GET_DEVICE_DETAILS(12),                    /* Get all registred devices for the user*/
		RDNA_METH_UPDATE_DEVICE_DETAILS(13);                 /* Update device details of the user*/

		public final int intValue;

		private RDNAMethodID(int val) {
			this.intValue = val;
		}
	}

	public enum RDNAErrorID {
		RDNA_ERR_NONE(0),                                    /* No Error                                             */

		RDNA_ERR_NOT_INITIALIZED(1),                         /* If core not initialized                              */
		RDNA_ERR_GENERIC_ERROR(2),                           /* If generic error occured                             */
		RDNA_ERR_INVALID_VERSION(3),                         /* If invalid SDK Version                               */
		RDNA_ERR_INVALID_ARGS(4),                            /* If invalid args are passed                           */
		RDNA_ERR_INVALID_CONTEXT(5),                         /* If invalid context is passed                         */
		RDNA_ERR_SESSION_EXPIRED(6), 						 /* If session has expired 								 */

		RDNA_ERR_FAILED_TO_CONNECT_VIA_PROXY (21),           /* If failed to connect to proxy server                 */ 
		RDNA_ERR_NULL_CALLBACKS(22),                         /* If Null callback/ptr passed in                       */
		RDNA_ERR_INVALID_HOST(23),                           /* If Null or empty hostname/IP                         */
		RDNA_ERR_INVALID_PORTNUM(24),                        /* If Invalid port number                               */
		RDNA_ERR_INVALID_AGENT_INFO(25),                     /* If agent info is invalid                             */
		RDNA_ERR_FAILED_TO_CONNECT_TO_SERVER(26),            /* If failed to connect to server                       */
		RDNA_ERR_FAILED_TO_AUTHENTICATE(27),                 /* If failed to authenticate                            */
		RDNA_ERR_INVALID_SAVED_CONTEXT(28),                  /* If Invalid saved context                             */
		RDNA_ERR_INVALID_HTTP_REQUEST(29),                   /* If Invalid HTTP request                              */
		RDNA_ERR_INVALID_HTTP_RESPONSE(30),                  /* If Invalid HTTP response                             */

		RDNA_ERR_INVALID_CIPHERSPECS(42),                    /* If cipherspecs is invalid                            */
		RDNA_ERR_PLAINTEXT_EMPTY(43),                        /* If plain text is empty in data packet/HTTP request   */
		RDNA_ERR_PLAINTEXT_LENGTH_INVALID(44),               /* If plain text length is empty/invalid                */
		RDNA_ERR_CIPHERTEXT_EMPTY(45),                       /* If cipher text is empty in data packet/HTTP request  */
		RDNA_ERR_CIPHERTEXT_LENGTH_INVALID(46),              /* If cipher text length is empty/invalid               */

		RDNA_ERR_SERVICE_NOT_SUPPORTED(61),                  /* If service not supported                             */
		RDNA_ERR_INVALID_SERVICE_NAME(62),                   /* If Invalid service name                              */


		RDNA_ERR_FAILED_TO_GET_STREAM_PRIVACYSCOPE(81),      /* If failed to get stream privacy scope                */
		RDNA_ERR_FAILED_TO_GET_STREAM_TYPE(82),              /* If failed to get stream type                         */
		RDNA_ERR_FAILED_TO_WRITE_INTO_STREAM(83),            /* If failed to write into data stream                  */
		RDNA_ERR_FAILED_TO_END_STREAM(84),                   /* If failed to end stream                              */
		RDNA_ERR_FAILED_TO_DESTROY_STREAM(85),               /* If failed to destroy stream                          */

		RDNA_ERR_FAILED_TO_INITIALIZE(101),                   /* If failed to initialize                              */
		RDNA_ERR_FAILED_TO_PAUSERUNTIME(102),                 /* If failed to pause runtime                           */
		RDNA_ERR_FAILED_TO_RESUMERUNTIME(103),                /* If failed to resume runtime                          */
		RDNA_ERR_FAILED_TO_TERMINATE(104),                    /* If failed to terminate                               */
		RDNA_ERR_FAILED_TO_GET_CIPHERSALT(105),              /* If failed to set cipherspecs                         */
		RDNA_ERR_FAILED_TO_GET_CIPHERSPECS(106),              /* If failed to get cipherspecs                         */
		RDNA_ERR_FAILED_TO_GET_AGENT_ID(107),                 /* If failed to get agent id                            */
		RDNA_ERR_FAILED_TO_GET_SESSION_ID(108),               /* If failed to get session id                          */
		RDNA_ERR_FAILED_TO_GET_DEVICE_ID(109),                /* If failed to get device id                           */
		RDNA_ERR_FAILED_TO_GET_SERVICE(110),                  /* If failed to get service                             */
		RDNA_ERR_FAILED_TO_START_SERVICE(111),                /* If failed to start service                           */
		RDNA_ERR_FAILED_TO_STOP_SERVICE(112),                 /* If failed to stop service                            */
		RDNA_ERR_FAILED_TO_ENCRYPT_DATA_PACKET(113),          /* If failed to encrypt data packet                     */
		RDNA_ERR_FAILED_TO_DECRYPT_DATA_PACKET(114),          /* If failed to decrypt data packet                     */
		RDNA_ERR_FAILED_TO_ENCRYPT_HTTP_REQUEST(115),         /* If failed to encrypt HTTP request                    */
		RDNA_ERR_FAILED_TO_DECRYPT_HTTP_RESPONSE(116),        /* If failed to decrypt HTTP response                   */
		RDNA_ERR_FAILED_TO_CREATE_PRIVACY_STREAM(117),        /* If failed to create privacy stream                   */
		RDNA_ERR_FAILED_TO_CHECK_CHALLENGE(118),             /* If failed to check credential                        */
		RDNA_ERR_FAILED_TO_UPDATE_CHALLENGE(119),             /*  If failed to update challenges                      */
		RDNA_ERR_FAILED_TO_GET_CONFIG(120),                   /* If failed to get config                              */
		RDNA_ERR_FAILED_TO_GET_ALL_CHALLENGES(121),           /* If failed to get all challenges                      */
		RDNA_ERR_FAILED_TO_LOGOFF(122),                       /* If failed to log off                                 */
		RDNA_ERR_FAILED_TO_RESET_CHALLENGE(123),
		RDNA_ERR_FAILED_TO_DO_FORGOT_PASSWORD(124),
		RDNA_ERR_FAILED_TO_SEND_DEV_DETAILS(125),
		RDNA_ERR_FAILED_TO_SET_DNS_SERVER(126),
		RDNA_ERR_USERID_EMPTY(127),                           /*If empty user id is provided to the api               */
		RDNA_ERR_CHALLENGE_EMPTY(128),
		RDNA_ERR_FAILED_TO_SERIALIZE_JSON(129),
		RDNA_ERR_FAILED_TO_DESERIALIZE_JSON(130),
		RDNA_ERR_INVALID_CHALLENGE_CONFIG(131),
		RDNA_ERR_FAILED_TO_GET_POST_LOGIN_CHALLENGES(132),      /* If failed to get post login challenges                    */
		RDNA_ERR_FAILED_TO_GET_REGISTERD_DEVICE_DETAILS(133),   /* If failed to get registered device details                */
		RDNA_ERR_FAILED_TO_UPDATE_DEVICE_DETAILS(134),          /* If failed to update registered device details           */
		RDNA_ERR_USECASE_EMPTY(135),                            /* If usecase is empty in get post login challenges   */
		RDNA_ERR_DEVICE_DETAILS_EMPTY(136),                     /* If device details empty in update device details     */
		RDNA_ERR_401_URL_EMPTY(137),                            /* If url is empty in setting iwa credentials                */
		RDNA_ERR_PASSWORD_EMPTY(138);                           /* If password is empty in setting iwa credentials      */

		public final int intValue;

		private RDNAErrorID(int val) {
			this.intValue = val;
		}
	}

	public enum RDNAStreamType {
		RDNA_STREAM_TYPE_ENCRYPT(0),                           /* a stream for encrypting */
		RDNA_STREAM_TYPE_DECRYPT(1);                           /* a stream for decrypting */

		public final int intValue;

		private RDNAStreamType(int val) {
			this.intValue = val;
		}
	}

	public enum RDNAPrivacyScope {
		RDNA_PRIVACY_SCOPE_SESSION(1),                        /* use session-specific keys */
		RDNA_PRIVACY_SCOPE_DEVICE(2),                         /* use device-specific keys */
		RDNA_PRIVACY_SCOPE_USER(3),                           /* use user-specific keys */
		RDNA_PRIVACY_SCOPE_AGENT(4);                          /* use agent-specific keys */

		public final int intValue;

		private RDNAPrivacyScope(int val) {
			this.intValue = val;
		}
	}

	public enum RDNAPortType {
		RDNA_PORT_TYPE_PROXY(0),                              /* port type is proxy */
		RDNA_PORT_TYPE_PORTF(1);                              /* port type is port forwarding */

		public final int intValue;

		private RDNAPortType(int val) {
			this.intValue = val;
		}
	}

	public static class RDNAPort {
		public boolean isStarted;                             /* Specifies whether the service access is enabled */
		public boolean isLocalhostOnly;                       /* Specifies whether the port is bound just on the local loopback interfaces */
		public boolean isAutoStarted;                         /* Specifies whether the service access was started as part of the API-runtime initialization */
		public boolean isPrivacyEnabled;                      /* Specifies whether use of the REL-ID Privacy API routines is mandated */
		public RDNAPortType portType;                         /* Type of the port : proxy or portf       */
		public int  port;                                     /* local port number for accessing service */

		public RDNAPort(int port, boolean isStarted, boolean isPrivacyEnabled,boolean isLocalhostOnly,boolean isAutoStarted,
				RDNAPortType portType) {

			this.port = port;
			this.isStarted = isStarted;
			this.isPrivacyEnabled = isPrivacyEnabled;
			this.portType = portType;
			this.isLocalhostOnly = isLocalhostOnly;
			this.isAutoStarted = isAutoStarted;
		}

		public RDNAPort(int port) {
			this.port = port;
		}
	}

	public static class RDNAService {
		public String serviceName;                           /* logical service name */
		public String targetHNIP;                            /* backend hostname/IP */
		public int targetPort;                               /* backend port number */
		public RDNAPort portInfo;                            /* port setting and info */

		/**
		 * @brief RDNAService   - Constructs the RDNAService object.
		 * @param serviceName   - Unique service name.
		 * @param targetHNIP    - Target Hostname/IP of service.
		 * @param targetPort    - Target port of service.
		 * @param portInfo      - RDNAPort object contaning port info service.
		 */ 
		public RDNAService(String serviceName, String targetHNIP, int targetPort,
				RDNAPort portInfo) {
			this.serviceName = serviceName;
			this.targetHNIP = targetHNIP;
			this.targetPort = targetPort;
			this.portInfo = portInfo;
		}

		/**
		 * @brief RDNAService   - Constructs the RDNAService object.
		 * @param serviceName   - Unique service name.
		 */ 
		public RDNAService(String serviceName) {
			this.serviceName = serviceName;
		}
	}

	public static class RDNAStatusInit {
		public Object pvtRuntimeCtx;                         /* Context of API runtime */
		public Object pvtAppCtx;                             /* Context of API-client */
		public int errCode;                                  /* Error code return */
		public RDNAMethodID methodID;                        /* Represents the callback method id*/
		public RDNAService services[];                       /* List of services */
		public RDNAPort pxyDetails;                          /* Proxy details */
		public RDNAChallenge[] challenges;                   /* List of initial challenges */

		/**
		 * @brief RDNAStatusInit            - Constructs RDNAStatusInit object.
		 * @param pvtRuntimeCtx             - Context of API runtime
		 * @param pvtAppCtx                 - Context of API-client
		 * @param errCode                   - Error code return
		 * @param methodID                  - Method identifier
		 * @param services                  - List of services
		 * @param pxyDetails                - Proxy details
		 * @param challenges                - List of initial challenges
		 */
		public RDNAStatusInit(Object pvtRuntimeCtx, Object pvtAppCtx,
				int errCode, RDNAMethodID methodID,
				RDNAService services[],RDNAPort pxyDetails, RDNAChallenge[] challenges) {
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
			this.services = services;
			this.pxyDetails = pxyDetails;
			this.challenges = challenges;

		}
	}

	public static class RDNAStatusLogOff {
		public Object pvtRuntimeCtx;                         /* Context of API runtime */
		public Object pvtAppCtx;                             /* Context of API-client */
		public int errCode;                                  /* Error code return */
		public RDNAMethodID methodID;                        /* Represent the callback method id*/
		public RDNAService services[];                       /* List of services */
		public RDNAPort pxyDetails;                          /* Proxy details */

		/**
		 * @brief RDNAStatusLogOff         - Constructs RDNAStatusLogOff object.
		 * @param pvtRuntimeCtx             - Context of API runtime
		 * @param pvtAppCtx                 - Context of API-client
		 * @param errCode                   - Error code return
		 * @param methodID                  - Method identifier
		 * @param services                  - List of services
		 * @param pxyDetails                - Proxy details
		 */
		public RDNAStatusLogOff(Object pvtRuntimeCtx, Object pvtAppCtx,
				int errCode, RDNAMethodID methodID,
				RDNAService services[],RDNAPort pxyDetails) {
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
			this.services = services;
			this.pxyDetails = pxyDetails;
		}
	}

	public static class RDNAStatusCheckChallengeResponse {
		public Object pvtRuntimeCtx;                         /* context of API runtime */
		public Object pvtAppCtx;                             /* context of API-client */
		public int errCode;                                  /* error code return */
		public RDNAMethodID methodID;                        /* callback method id */
		public RDNAChallengeStatus status;                   /* status of challenge request */ 
		public RDNAChallenge[] challenges;                   /* list of challenges returned on challenge request */
		public RDNAService services[];                       /* List of services */
		public RDNAPort pxyDetails;

		/**
		 * @brief RDNAStatusCheckChallenge  - Constructs RDNAStatusCheckChallenge object.
		 * @param pvtRuntimeCtx             - Context of API runtime
		 * @param pvtAppCtx                 - Context of API-client
		 * @param errCode                   - Error code return
		 * @param methodID                  - Method identifier
		 * @param status                    - Status of challenge request
		 * @param challenges                - List of challenges returned on challenge request
		 */
		public RDNAStatusCheckChallengeResponse(Object pvtRuntimeCtx, Object pvtAppCtx,
				int errCode, RDNAMethodID methodID, RDNAChallengeStatus status, RDNAChallenge[] challenges, RDNAService services[],RDNAPort pxyDetails) {
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.services = services;
			this.methodID = methodID;
			this.status = status;
			this.challenges = challenges;
			this.pxyDetails = pxyDetails;
		}
	}

	public static class RDNAStatusGetAllChallenges {
		public Object pvtRuntimeCtx;                         /* context of API runtime */
		public Object pvtAppCtx;                             /* context of API-client */
		public int errCode;                                  /* error code return */
		public RDNAMethodID methodID;                        /* callback method id */
		public RDNAChallengeStatus status;                   /* status of challenge request */ 
		public RDNAChallenge[] challenges;                   /* list of challenges returned on challenge request */

		/**
		 * @brief RDNAStatusCheckChallenge  - Constructs RDNAStatusCheckChallenge object.
		 * @param pvtRuntimeCtx             - Context of API runtime
		 * @param pvtAppCtx                 - Context of API-client
		 * @param errCode                   - Error code return
		 * @param methodID                  - Method identifier
		 * @param status                    - Status of challenge request
		 * @param challenges                - List of challenges returned on challenge request
		 */
		public RDNAStatusGetAllChallenges(Object pvtRuntimeCtx, Object pvtAppCtx,
				int errCode, RDNAMethodID methodID, RDNAChallengeStatus status, RDNAChallenge[] challenges) {
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
			this.status = status;
			this.challenges = challenges;
		}
	}

	public static class RDNAStatusForgotPassword {
		public Object pvtRuntimeCtx;                         /* context of API runtime */
		public Object pvtAppCtx;                             /* context of API-client */
		public int errCode;                                  /* error code return */
		public RDNAMethodID methodID;                        /* callback method id */
		public RDNAChallengeStatus status;                   /* status of challenge request */ 
		public RDNAChallenge[] challenges;                   /* list of challenges returned on challenge request */

		/**
		 * @brief RDNAStatusCheckChallenge  - Constructs RDNAStatusCheckChallenge object.
		 * @param pvtRuntimeCtx             - Context of API runtime
		 * @param pvtAppCtx                 - Context of API-client
		 * @param errCode                   - Error code return
		 * @param methodID                  - Method identifier
		 * @param status                    - Status of challenge request
		 * @param challenges                - List of challenges returned on challenge request
		 */
		public RDNAStatusForgotPassword(Object pvtRuntimeCtx, Object pvtAppCtx,
				int errCode, RDNAMethodID methodID, RDNAChallengeStatus status, RDNAChallenge[] challenges) {
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
			this.status = status;
			this.challenges = challenges;
		}
	}

	public static class RDNAStatusUpdateChallenges {
		public Object pvtRuntimeCtx;                         /* context of API runtime */
		public Object pvtAppCtx;                             /* context of API-client */
		public int errCode;                                  /* error code return */
		public RDNAMethodID methodID;                        /* callback method id */
		public RDNAChallengeStatus status;                   /* status of challenge request */ 
		public RDNAChallenge[] challenges;                   /* list of challenges returned on challenge request */

		/**
		 * @brief RDNAStatusCheckChallenge  - Constructs RDNAStatusCheckChallenge object.
		 * @param pvtRuntimeCtx             - Context of API runtime
		 * @param pvtAppCtx                 - Context of API-client
		 * @param errCode                   - Error code return
		 * @param methodID                  - Method identifier
		 * @param status                    - Status of challenge request
		 * @param challenges                - List of challenges returned on challenge request
		 */
		public RDNAStatusUpdateChallenges(Object pvtRuntimeCtx, Object pvtAppCtx,
				int errCode, RDNAMethodID methodID, RDNAChallengeStatus status, RDNAChallenge[] challenges) {
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
			this.status = status;
			this.challenges = challenges;
		}
	}

	public static class RDNAStatusGetPostLoginChallenges{
		public Object pvtRuntimeCtx;                         /* context of API runtime */
		public Object pvtAppCtx;                             /* context of API-client */
		public int errCode;                                  /* error code return */
		public RDNAMethodID methodID;                        /* represent the callback method id*/
		public RDNAChallengeStatus status;                   /* status of challenge request */ 
		public RDNAChallenge[] challenges;                   /* list of challenges returned on challenge request */

		/**
		 * @brief RDNAStatusGetPostLoginChallenges  - Constructs RDNAStatusCheckChallenge object.
		 * @param pvtRuntimeCtx                     - Context of API runtime
		 * @param pvtAppCtx                         - Context of API-client
		 * @param errCode                           - Error code return
		 * @param methodID                          - Method identifier
		 * @param status                            - Status of challenge request
		 * @param challenges                        - List of challenges returned on challenge request
		 */
		public RDNAStatusGetPostLoginChallenges(Object pvtRuntimeCtx, Object pvtAppCtx,
				int errCode, RDNAMethodID methodID, RDNAChallengeStatus status, RDNAChallenge[] challenges) {
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
			this.status = status;
			this.challenges = challenges;
		}
	}

	public static class RDNAStatusTerminate {
		public Object pvtRuntimeCtx;                         /* context of API runtime */
		public Object pvtAppCtx;                             /* context of API-client */
		public int errCode;                                  /* error code return */
		public RDNAMethodID methodID;                        /* represent the callback method id*/

		/**
		 * @brief RDNAStatusTerminate       - Constructs RDNAStatusTerminate object.
		 * @param pvtRuntimeCtx             - Context of API runtime
		 * @param pvtAppCtx                 - Context of API-client
		 * @param errCode                   - Error code return
		 * @param methodID                  - Method identifier
		 */
		public RDNAStatusTerminate(Object pvtRuntimeCtx, Object pvtAppCtx,
				int errCode, RDNAMethodID methodID) {
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
		}
	}

	public static class RDNAStatusPause {
		public Object pvtRuntimeCtx;                         /* context of API runtime */
		public Object pvtAppCtx;                             /* context of API-client */
		public int errCode;                                  /* error code return */
		public RDNAMethodID methodID;                        /* represent the callback method id*/

		/**
		 * @brief RDNAStatusPause           - Constructs RDNAStatusPause object.
		 * @param pvtRuntimeCtx             - Context of API runtime
		 * @param pvtAppCtx                 - Context of API-client
		 * @param errCode                   - Error code return
		 * @param methodID                  - Method identifier
		 */
		public RDNAStatusPause(Object pvtRuntimeCtx, Object pvtAppCtx,
				int errCode, RDNAMethodID methodID) {
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
		}
	}

	public static class RDNAStatusResume {
		public Object pvtRuntimeCtx;                         /* context of API runtime */
		public Object pvtAppCtx;                             /* context of API-client */
		public int errCode;                                  /* error code return */
		public RDNAMethodID methodID;                        /* represent the callback method id*/
		public RDNAService services[];
		public RDNAPort pxyDetails;


		/**
		 * @brief RDNAStatusResume          - Constructs RDNAStatusResume object.
		 * @param pvtRuntimeCtx             - Context of API runtime
		 * @param pvtAppCtx                 - Context of API-client
		 * @param errCode                   - Error code return
		 * @param methodID                  - Method identifier
		 * @param services                  - List of services
		 * @param pxyDetails                - Proxy details
		 */
		public RDNAStatusResume(Object pvtRuntimeCtx, Object pvtAppCtx,
				int errCode, RDNAMethodID methodID,
				RDNAService services[],RDNAPort pxyDetails) {
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
			this.services = services;
			this.pxyDetails = pxyDetails;

		}
	}

	public static class RDNAStatusGetConfig{
		public Object pvtRuntimeCtx;                         /* context of API runtime */
		public Object pvtAppCtx;                             /* context of API-client */
		public int errCode;                                  /* error code return */
		public RDNAMethodID methodID;                        /* represent the callback method id*/
		public String responseData;

		/**
		 * @brief RDNAStatusGetConfig       - Constructs RDNAStatusGetConfig object.
		 * @param pvtRuntimeCtx             - Context of API runtime
		 * @param pvtAppCtx                 - Context of API-client
		 * @param errCode                   - Error code return
		 * @param methodID                  - Method identifier
		 * @param responseData              - Configuration json data
		 */
		public RDNAStatusGetConfig(Object pvtRuntimeCtx, Object pvtAppCtx,
				int errCode, RDNAMethodID methodID,
				String responseData) {
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
			this.responseData = responseData;
		}
	}

	public static class RDNAProxySettings {
		public String proxyHNIP;                            /* Proxy server's hostname/IP-address */
		public int proxyPort;                               /* Proxy server's port number */
		public String username;                             /* Username for authentication, if applicable */
		public String password;                             /* Password for authentication, if applicable */

		/**
		 * @brief RDNAProxySettings   - Constructs the RDNAProxySetting object.
		 * @param proxyHNIP           - Hostname/IP of the proxy server.
		 * @param proxyPort           - Port of proxy server
		 * @param username            - Proxy server authentication username. 
		 * @param password            - Proxy server authentication password. 
		 */ 
		public RDNAProxySettings(String proxyHNIP, int proxyPort,
				String username, String password) {
			this.proxyHNIP = proxyHNIP;
			this.proxyPort = proxyPort;
			this.username = username;
			this.password = password;
		}
	}
	

	public static class RDNAStatusGetRegisteredDeviceDetails{
		public Object pvtRuntimeCtx;                         /* context of API runtime */
		public Object pvtAppCtx;                             /* context of API-client */
		public int errCode;                                  /* error code return */
		public RDNAMethodID methodID;                        /* represent the callback method id*/
		public RDNADeviceDetails[] devices;					 /* list of users registered devices*/
		public RDNAChallengeStatus challengeStatus; 		 /* response status */
		
		/**
		  @brief RDNAStatusGetRegisteredDeviceDetails - This will return all the devices,registered by the user, 
		  user can be able to delete the devices or change the device name.

		 * @param pvtRuntimeCtx             - Context of API runtime
		 * @param pvtAppCtx                 - Context of API-client
		 * @param errCode                   - Error code return
		 * @param methodID                  - Method identifier
		 * @param devices                   - list of users registered devices
		 * @param challengeStatus           - Response status 
		 */
		public RDNAStatusGetRegisteredDeviceDetails(Object pvtRuntimeCtx,Object pvtAppCtx,
				int errCode,RDNAMethodID methodID,RDNADeviceDetails[] devices,RDNAChallengeStatus challengeStatus){
			
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
			this.devices  = devices;
			this.challengeStatus = challengeStatus;
		}
	}
	
	public static class RDNAStatusUpdateDeviceDetails{
		
		public Object pvtRuntimeCtx;                         /* context of API runtime */
		public Object pvtAppCtx;                             /* context of API-client */
		public int errCode;                                  /* error code return */
		public RDNAMethodID methodID;                        /* represent the callback method id*/
		public RDNAChallengeStatus challengeStatus; 		 /* response status */
		
		/**
		  @brief RDNAStatusUpdateDeviceDetails - This is update device details status object, which will return the status
		 * @param pvtRuntimeCtx                - Context of API runtime
		 * @param pvtAppCtx                    - Context of API-client
		 * @param errCode                      - Error code return
		 * @param methodID                     - Method identifier 
		 * @param challengeStatus              - Response status 
		 */
		
		public RDNAStatusUpdateDeviceDetails(Object pvtRuntimeCtx,Object pvtAppCtx,
				int errCode,RDNAMethodID methodID,RDNAChallengeStatus challengeStatus)
		{
			this.pvtRuntimeCtx = pvtRuntimeCtx;
			this.pvtAppCtx = pvtAppCtx;
			this.errCode = errCode;
			this.methodID = methodID;
			this.challengeStatus = challengeStatus;
		}
	}
	
	public abstract static class RDNADeviceDetails{
		protected String deviceUUID;
		protected String deviceName;
		protected final RDNADeviceBinding deviceBinding;
		protected RDNADeviceStatus deviceStatus;
		protected final String deviceRegistrationTime; 
		protected final String lastAccessTime;
		protected final String lastLoginStatus;
		
		public RDNADeviceDetails(String deviceUUID,String deviceName,RDNADeviceBinding deviceBinding,RDNADeviceStatus deviceStatus,String deviceRegistrationTime,String lastAccessTime,String
				lastLoginStatus)
		{
			this.deviceUUID = deviceUUID;
			this.deviceName = deviceName;
			this.deviceBinding = deviceBinding;
			this.deviceStatus = deviceStatus;
			this.deviceRegistrationTime = deviceRegistrationTime;
			this.lastAccessTime = lastAccessTime;
			this.lastLoginStatus = lastLoginStatus;
		}
		
		
		public abstract void setNewDeviceName(String newDeviceName);
		
		public abstract void deleteDevice();
		
		public abstract RDNADeviceStatus getDeviceStatus();
		
		public abstract String getDeviceUUID();
		
		public abstract String getDeviceName();
		
		public abstract RDNADeviceBinding getDeviceBinding();
		
		public abstract String getDeviceRegistrationTime();
		
		public abstract String getLastAccessTime();
		
		public abstract String getLastLoginStatus();
	}
	
	public static class RDNAIWACreds{
		public String userName;
		public String userPassword;
		public RDNAIWAAuthStatus status;

		public RDNAIWACreds() {}

		public RDNAIWACreds(String userName,String userPassword,RDNAIWAAuthStatus status){
			this.userName = userName;
			this.userPassword = userPassword;
			this.status = status;
		}
	}

	public enum RDNAIWAAuthStatus{
		AUTH_SUCCESS(0),
		AUTH_CANCELLED(1),
		AUTH_DEFERRED(2);

		public int intVal;

		private RDNAIWAAuthStatus(int val){
			this.intVal = val;
		}
	}

	/**
	 * RDNAPrivacyStreamCallBacks - This is a callback routine supplied by the API-client.
	 */
	public static interface RDNAPrivacyStreamCallBacks {

		/**
		 * @brief onBlockReady      - This routine is invoked from within the WriteDataIntoStream routine,
		 *                            when the requisite number of blocks are ready for consumption by the API-client
		 *                            (i.e. when that many blocks have been encrypted/decrypted)
		 * @param rdnaPrivStream    - RDNA Privacy stream reference.
		 * @param pvBlockReadyCtx   - Opaque block ready context passed by API-Client
		 * @param pvBlockBuf        - Encrypted/Decrypted data block which is ready
		 * @param nBlockSize        - Data block size.
		 * @return                  - If success return 0 else appropriate error code.
		 */
		int onBlockReady(RDNAPrivacyStream rdnaPrivStream,
				Object pvBlockReadyCtx,
				byte[] pvBlockBuf, int nBlockSize);
	};

	public static interface RDNAPrivacyStream {

		/**
		 * @brief getPrivacyScope - Method to get Privacy scope of privacy stream.
		 * @return                - If success returns 0 with PrivacyScope enum otherwise appropriate error code.
		 */
		public RDNAStatus<RDNAPrivacyScope> getPrivacyScope();

		/**
		 * @brief getStreamType - Method to get Privacy stream type
		 * @return              - If success returns 0 with StreamType enum otherwise appropriate error code
		 */
		public RDNAStatus<RDNAStreamType> getStreamType();

		/**
		 * @brief writeDataIntoStream - Method is used to write data into Privacy stream.
		 * @param data                - Data to be written in privacy stream.
		 * @return                    - If success returns 0 else appropriate error code.
		 */
		public int writeDataIntoStream(byte[] data);

		/**
		 * @brief endStream           - Method called to end Privacy stream
		 * @return                    - If success returns 0 else appropriate error code.
		 */
		public int endStream();

		/**
		 * @brief destroy             - Method called to do the destroy activity on the stream.
		 * @return                    - If success returns 0 else appropriate error code.
		 */
		public int destroy();
	}

	/**
	 * @brief createPrivacyStream - Method creates a private stream defined within
	 *                              the scope of privacy.
	 * @param streamType          - Type of stream (Encrypt/Decrypt)
	 * @param privacyScope        - Privacy scope of the stream.
	 * @param cipherSpec          - Cipher to be used.
	 * @param cipherSalt          - Cipher salt.
	 * @param blockReadyThreshold - Input block size from application,Min = 1 and
	 *                              Max = 64: If blockReadySize = 0 then core will
	 *                              assign default Max(64) value else the value
	 *                              specified by application is set, Incase if
	 *                              blockReadySize > MAX assert is thrown.
	 * @param callbacks           - Object of RDNAPrivacyStreamCallBacks.
	 * @param pvBlockReadyCtx     - Opaque context pointer to be passed to the
	 *                              block-ready callback routine when it is invoked.
	 * @return                    - Returns RDNAStatus with error code 0 and RDNAPrivacyStream object in result or appropriate error code.
	 */
	public abstract RDNAStatus<RDNAPrivacyStream> createPrivacyStream(
			RDNAStreamType streamType, RDNAPrivacyScope privacyScope, String cipherSpecs,
			String cipherSalt, int blockReadyThreshold,
			RDNAPrivacyStreamCallBacks callbacks, Object pvBlockReadyCtx);

	public static interface RDNACallbacks {

		/**
		 * @brief onInitializeCompleted  - Method is called by the RDNA to notify the client that the initialize is complete.
		 * @param status                 - status of initialize flow, app context,error code returned by core, auto started services, method id
		 *
		 */
		public int onInitializeCompleted(RDNAStatusInit status);


		/**
		 * @brief getDeviceContext - Method takes android application context.
		 * @return                 - returns the android application context.
		 */
		public Object getDeviceContext();

		/**
		 * @brief getApplicationFingerprint - This method is invoked by the API runtime during initialization (session creation)
		 *                                    in order to retrieve the application fingerprint, supplied by the API-client application to include in the device details.
		 *                                    The intent of this routine is to provide the application with an opportunity
		 *                                    to identify itself so that the backend can check integrity of the application.
		 *                                    To this end, it is recommended that the application provide strong checksums which can be matched/recorded at the backend.
		 * @return -                          App's fingerprint data to be set into the device details.
		 */
		public String getApplicationFingerprint();

		/**
		 * @brief onTerminate  - Method is called by the RDNA to notify the
		 *                       client that the terminate is complete.
		 * @param status       - status of terminate flow, app context,
		 *                       error code returned by core, method id.
		 */
		public int onTerminate(RDNAStatusTerminate status);

		/**
		 * @brief onPauseRuntime - Method is called by the RDNA to notify the
		 *                         client that the pauseRuntime is complete.
		 * @param status         - status of pauseRuntime flow, app context,
		 *                         error code returned by core, method id.
		 */
		public int onPauseRuntime(RDNAStatusPause status);

		/**
		 * @brief onResumeRuntime - Method is called by the RDNA to notify the
		 *                          client that the resumeRuntime is complete.
		 * @param status          - Status of resumeRuntime flow, app context,
		 *                          error code returned by core, auto started services,
		 *                          method id.
		 */
		public int onResumeRuntime(RDNAStatusResume status);

		/**
		 * @brief onConfigRecieved      - Callback invoked as a response of challenge request call. 
		 * @param status          - Contains response of challenge request call.
		 */
		public int onConfigReceived(RDNAStatusGetConfig status);

		/**
		 * @onChallengeReceived   - Callback invoked as a response of challenge request call. 
		 * @param status          - Contains response of challenge request call.
		 */
		public int onCheckChallengeResponseStatus(RDNAStatusCheckChallengeResponse status);

		public int onGetAllChallengeStatus(RDNAStatusGetAllChallenges status);

		public int onUpdateChallengeStatus(RDNAStatusUpdateChallenges status);

		public int onForgotPasswordStatus(RDNAStatusForgotPassword status);

		public int onGetPostLoginChallenges(RDNAStatusGetPostLoginChallenges status);

		public int onLogOff(RDNAStatusLogOff status);

		public RDNAIWACreds getCredentials(String domainUrl);

		public String getApplicationName();

		public String getApplicationVersion();

		 /**
		   * @brief onGetRegistredDeviceDetails - Method is called by the API runtime to notify that
		   *                                      the device details are received.
		   * @param status                      - status of get post login challenges, which contains app context,
		   *                                      error code returned by core, method id, and all the devices registred by the User
		   */
		public int onGetRegistredDeviceDetails(RDNAStatusGetRegisteredDeviceDetails status);

		  /**
		   * @brief onUpdateDeviceDetails - Method is called by the API runtime to notify that
		   *                                the device details are updated
		   * @param status                - status of get post login challenges, which contains app context,
		   *                                error code returned by core, method id
		   */
		public int onUpdateDeviceDetails(RDNAStatusUpdateDeviceDetails status);
		
	}

	protected RDNA() {
	}

	/**
	 * @brief Initialize   - Initializes the sdk by connecting out to given REL-ID
	 * @param agentInfo    - Software identity information for the API-runtime to
	 *                       authenticate and establish primary session connectivity with the
	 *                       REL-ID platform backend.
	 * @param callbacks
	 *                     - client callback object for notify the status.
	 * @param gwHNIP
	 *                     - Hostname/IP of the gateway server
	 * @param gwPort
	 *                     - Port of the gateway server
	 * @param cipherSpec
	 *                     - Cipher mode to be used
	 * @param cipherSalt
	 *                     - Cipher salt to be used
	 * @param proxySettings
	 *                     - Parent proxy settings of the application
	 * @param appCtx
	 *                     - Application context
	 * @return             - Returns RDNAStatus object with error code 0 and RDNA object in result or appropriate error code.
	 */
	public static RDNAStatus<RDNA> Initialize(String agentInfo, RDNACallbacks callbacks,
			String authGatewayHNIP, int authGatewayPORT,
			String cipherSpecs, String cipherSalt,
			RDNAProxySettings proxySettings, Object appCtx) {

		return RDNAImpl.Initialize(agentInfo, callbacks, authGatewayHNIP, authGatewayPORT,
				cipherSpecs, cipherSalt, proxySettings, appCtx);
	}

	/**
	 * @brief getServiceByServiceName - Method is used to get the details of the
	 *                                  tunneling service w.r.t. its name.
	 * @param serviceName             - Name of the service.
	 * @return                        - Returns RDNAStatus object with error code 0 and RDNAService object containing the service details in result field or appropriate error code.
	 */
	public abstract RDNAStatus<RDNAService> getServiceByServiceName(String serviceName);

	/**
	 * @brief getServiceByTargetCoordinate - Method is used to get the details of the
                                           tunneling service/s w.r.t. its destination coordinates.
	 * @param targetHNIP                   - Destination host-name/IP of the service
	 * @param targetPORT                   - Destination port of the service.
	 * @return                             - Returns RDNAStatus object with error code 0 and list of objects containing service details in result field or returns appropriate error code.
	 */
	public abstract RDNAStatus<RDNAService[]> getServiceByTargetCoordinate(
			String targetHNIP, int targetPORT);

	/**
	 * @brief getAllServices - Return's list of all the services configured.
	 * @return               - Returns RDNAStatus object with error code 0 and list of objects containing service details in result field or returns appropriate error code.
	 */
	public abstract RDNAStatus<RDNAService[]> getAllServices();

	/**
	 * @brief serviceAccessStart - Method called to start a particular
	 *                             tunneling service.
	 * @param service            - Object containing the service details. Name is mandatory and the
	 *                             only parameter to uniquely identify the service.
	 * @return                   - Appropriate error code of the error that occurred or success.
	 */
	public abstract int serviceAccessStart(RDNAService service);

	/**
	 * @brief serviceAccessStop - Method stops a particular tunneling service.
	 * @param service           - Object containing the service details. Name is mandatory and the
	 *                            only parameter to uniquely identify the service.
	 * @return                  - Appropriate error code of the error that occurred or success.
	 */
	public abstract int serviceAccessStop(RDNAService service);

	/**
	 * @brief serviceAccessStartAll - starts all the non-running tunneling services
	 * @return                      - Appropriate error code that occurred or success.
	 */
	public abstract int serviceAccessStartAll();

	/**
	 * @brief serviceAccessStopAll - All stops all the running tunneling services
	 * @return                     - Returns 0 on success or appropriate error code.
	 */
	public abstract int serviceAccessStopAll();


	/**
	 * @brief pauseRuntime - Signals the RDNA to pause its execution and save the
	 *                       its state and return it to caller.
	 * @return             - Returns RDNAStatus object with error code 0 and runtime state to be saved or appropriate error code.
	 */
	public abstract RDNAStatus<byte[]> pauseRuntime();


	/**
	 * @brief resumeRuntime - Method to signal the DNA thread to resume execution.
	 * @param state         - Previously saved runtime state.
	 * @param callbacks     - Pointer to the RDNA callbacks object.
	 * @param proxySettings - Parent proxy settings of the application.
	 * @param appCtx        - Application context.
	 * @return              - Returns RDNAStatus object with error code 0 and RDNA object in result or appropriate error code.
	 */
	public static RDNAStatus<RDNA> resumeRuntime(byte[] state,
			RDNACallbacks callbacks, RDNAProxySettings proxySettings, Object appCtx) {
		return RDNAImpl.resumeRuntime(state, callbacks, proxySettings, appCtx);
	}


	/**
	 * @brief getDefaultCipherSpec - Method to get the default cipher spec.
	 * @return                     - Returns RDNAStatus object with error code 0 and cipher specification in result or appropriate error code.
	 */
	public abstract RDNAStatus<String> getDefaultCipherSpec();

	/**
	 * @brief getDefaultCipherSalt - Method to get the default cipher salt.
	 * @return                     - Returns RDNAStatus object with error code 0 and ciphersalt specification in result or appropriate error code.
	 */
	public abstract RDNAStatus<byte[]> getDefaultCipherSalt();

	/**
	 * @brief encryptDataPacket - Method used to encrypt the data packet.
	 * @param privacyScope      - Privacy scope of the data packet.
	 * @param cipherSpec        - Cipher to be used.
	 * @param cipherSalt        - Cipher salt.
	 * @param plainText         - Input the plain string data packet.
	 * @return                  - Returns RDNAStatus object with error code 0 and cipher text data packet in result or appropriate error code.
	 */
	public abstract RDNAStatus<byte[]> encryptDataPacket(
			RDNAPrivacyScope privacyScope,
			String cipherSpec, byte[] cipherSalt,
			byte[] plainText);

	/**
	 * @brief decryptDataPacket - This method decrypts the data packet provided and returns the plain
	 *                            text if successful else the appropriate error code.
	 * @param privacyScope      - Privacy scope of the data packet.
	 * @param cipherSpec        - Cipher to be used.
	 * @param cipherSalt        - Cipher salt.
	 * @param cipherText        - Input encrypted data packet.
	 * @return                  - Returns RDNAStatus object with error code 0 and plain text data packet in result or appropriate error code.
	 */
	public abstract RDNAStatus<byte[]> decryptDataPacket(
			RDNAPrivacyScope privacyScope,
			String cipherSpec, byte[] cipherSalt,
			byte[] cipherText);

	/**
	 * @brief encryptHttpRequest - This method encrypts the original HTTP request and encapsulates it
	 *                             into a dummy HTTP request with same destination as the original
	 *                             request.
	 * @param privacyScope       - Privacy scope of the stream.
	 * @param cipherSpec         - Cipher to be used.
	 * @param cipherSalt         - Cipher salt.
	 * @param request            - Input plain text formatted http request.
	 * @return                   - Returns RDNAStatus object with error code 0 and formatted cipher text request in result or appropriate error code.
	 */
	public abstract RDNAStatus<String> encryptHttpRequest(
			RDNAPrivacyScope privacyScope,
			String cipherSpec, byte[] cipherSalt,
			String request);

	/**
	 * @brief decryptHttpResponse - This method decrypts the HTTP response and returns back the plain
	 *                              string original http response string.
	 * @param privacyScope        - Privacy scope of the stream.
	 * @param cipherSpec          - Cipher to be used.
	 * @param cipherSalt          - Cipher salt.
	 * @param transformedResponse - Input encrypted HTTP response string.
	 * @return                    - Returns RDNAStatus object with error code 0 and decrypted http response in result or appropriate error code. 
	 */
	public abstract RDNAStatus<String> decryptHttpResponse(
			RDNAPrivacyScope privacyScope,
			String cipherSpec, byte[] cipherSalt,
			String transformedResponse);

	/**
	 * @brief terminate - This method terminates the RDNA context.
	 * @return          - Appropriate error code of the error that occurred.
	 */
	public abstract int terminate();

	/**
	 * @brief getSessionID - This method returns the session ID of the current initialized REL-ID session.
	 * @return             - Returns RDNAStatus object with error code 0 and Session ID string in result or appropriate error code.
	 */
	public abstract RDNAStatus<String> getSessionID();

	/**
	 * @brief getAgentID - This method returns the Agent ID using which the REL-ID session is initialized.
	 * @return           - Returns RDNAStatus object with error code 0 and Agent ID string in result or appropriate error code. 
	 */
	public abstract RDNAStatus<String> getAgentID();

	/**
	 * @brief getDeviceID - This method returns the device ID of the current device using which the REL-ID session is initialized.
	 * @return            - Returns RDNAStatus object with error code 0 and Device ID string in result or appropriate error code. 
	 */
	public abstract RDNAStatus<String> getDeviceID();

	/**
	 * @brief getSDKVersion - Returns the current sdk version.
	 * @return              - Returns the current sdk version string.
	 */
	public static String getSDKVersion() {
		return RDNAImpl.getSDKVersion();
	}

	/**
	 * @brief getErrorInfo - Method is called to get enum value from error code.
	 * @param errorCode    - Integer error code returned by API-SDK methods.
	 * @return             - Return the RDNAErrChallengeStatusorID enum.
	 */
	public static RDNAErrorID getErrorInfo(int errorCode) {
		RDNAErrorID errorDetail = RDNAImpl.decodeError(errorCode);
		return errorDetail;
	}

	/**
	 * @brief getConfig - This method can be used for any state primary or secondary of the RDNA context, and this is used to get the configuration setting from the server.
	 * @param userID    - Unique user id.  
	 * @returns         - Returns 0 on success or appropriate error code.
	 */
	public abstract int getConfig(String userID);

	/**
	 * @brief getAllChallengesForUserID - This method is used to get all challenges. 
	 * @param userID                    - Unique id of user.
	 * @return                          - Returns 0 if success or appropriate error code.
	 */
	public abstract int getAllChallenges(String userID);

	/**
	 * @brief checkChallengesForUserID - This method is used to send the response of challenges to server for authentication.
	 * @param challenges               - Challenges with response set to it.
	 * @param userID                   - Unique user id
	 * @return                         - Returns 0 if success or appropriate error code.      
	 */
	public abstract int checkChallenges(RDNAChallenge[] challenges,String userID);

	/**
	 * @brief updateChallengesForUserID - This method is used to update the challenges.
	 * @param challenges                - List of challenges to update
	 * @param userID                    - Unique user id
	 * @return                          - Returns 0 if success or appropriate error code.
	 */
	public abstract int updateChallenges(RDNAChallenge[] challenges,String userID);

	/**
	 * @brief logOffForUserID - This method is used to log off the user session.
	 * @param userID          - Unique user id to log off
	 * @return                - Returns 0 if success or appropriate error code.
	 */
	public abstract int logOff(String userID);

	/**
	 * @brief resetChallenge - This method is used to reset the challenge
	 *                         flow/sequence to the initial challenge received in onInitializeCompleted callback.
	 * @return               - Returns 0 if success or appropriate error code.
	 */
	public abstract int resetChallenge();

	public abstract int forgotPassword(String userID);

	public abstract int setDnsServer(String[] dnsServer);

	/**
	 * @brief getPostLoginChallenges - This Method is used to perform the user's authentication if required,
	 *                                  API client can use this API only after the user is successfully logged in, and API client wants 
	 *                                  authenticate the user with some extra challenge 
	 * @param userID                 - User id
	 * @param useCaseName            - input use case name, which can be set by the API client.
	 * @return                       - Returns 0 if success or appropriate error code.
	 */
	public abstract int getPostLoginChallenges(String userID, String useCaseName);
	
	/**
	 * @brief getRegisteredDeviceDetails - This Method is used get all the devices registered by the user,
	 *                                     API client can use this API only after the user is successfully logged in, and API client wants 
	 *                                     to give an authority to user manage it's devices to update the name or delete the device from the list
	 * @param userID                     - User id
	 * @return                           - If success returns 0 else appropriate error code.
	 */
	public abstract int getRegisteredDeviceDetails(String userID);

	/**
	 * @brief getRegisteredDeviceDetails - This Method is used update the devices registered by the user,
	 *                                     API client can use this API only after the user is successfully logged in, and user has updated it's 
	 *                                     device details, may be deletion of the device and updating the device name.
	 * @param userID                     - User id
	 * @return                           - If success returns 0 else appropriate error code.
	 */
	public abstract int updateDeviceDetails(String userID,RDNADeviceDetails[] devices);

	

	public static class RDNAChallenge {
		private boolean shouldCheckResponseValidation;
		private int index;
		private int attemptsLeft;
		private String name;
		private LinkedHashMap<String, String> info;
		private String responseKey;
		private Object responseValue;
		private String[] prompts;
		private String[] responsePolicies;
		private int subChallengeIndex;
		private RDNAChallengeType type;

		public String getName() {
			return name;
		}

		void setName(String name) {
			this.name = name;
		}

		public RDNAChallengeType getType() {
			return type;
		}

		void setType(RDNAChallengeType type) {
			this.type = type;
		}

		public int getIndex() {
			return index;
		}

		public String getResponseKey(){
			return responseKey;
		}

		public Object getResponseValue(){
			return responseValue;
		}

		void setResponse(String key,Object value){
			this.responseKey = key;
			this.responseValue = value;
		}

		void setIndex(int index) {
			this.index = index;
		}

		public LinkedHashMap<String, String> getInfoMap() {
			return info;
		}
		void setInfoMap(LinkedHashMap<String, String> infoMap) {
			this.info = infoMap;
		}

		public String[] getPrompts() {
			return prompts;
		}

		void setPrompts(String[] prompts) {
			this.prompts = prompts;
		}

		public int getAttemptsLeft() {
			return attemptsLeft;
		}

		void setAttemptsLeft(int attemptsLeft) {
			this.attemptsLeft = attemptsLeft;
		}

		public boolean getResponseValidation() {
			return shouldCheckResponseValidation;
		}

		void setResponseValidation(boolean responseValidation) {
			this.shouldCheckResponseValidation = responseValidation;
		}

		public String[] getResponsePolicies() {
			return responsePolicies;
		}

		void setResponsePolicies(String[] responsePolicy) {
			this.responsePolicies = responsePolicy;
		}

		void setSubChallengeIndex(int index){
			subChallengeIndex = index;
		}

		public int getSubChallengeIndex(){
			return subChallengeIndex;
		}

		public int setChallengeResponseForKey(String challengeResponseKey,Object response){
			if(null != challengeResponseKey && null != response){
				switch (type) {
				//        case ONE_WAY_PROMPT:
				//case TWO_WAY_PROMPT_READONLY:
				//        case BOOLEAN_PROMPT:
				//          if(this.responseKey.equals(challengeResponseKey)){
				//            this.responseValue = response;
				//            return RDNAErrorID.RDNA_ERR_NONE.intValue;
				//          } else{
				//            return RDNAErrorID.RDNA_ERR_INVALID_ARGS.intValue;
				//          }
				case RDNA_PROMPT_ONE_WAY:
				case RDNA_PROMPT_BOOLEAN:
				case RDNA_PROMPT_TWO_WAY:
					this.responseKey = challengeResponseKey;
					this.responseValue = response;
					return RDNAErrorID.RDNA_ERR_NONE.intValue;
				default:
					break;
				}
			}

			return RDNAErrorID.RDNA_ERR_INVALID_ARGS.intValue;
		}

		static Comparator<RDNAChallenge> RDNAChallengeIndexComparator = new Comparator<RDNA.RDNAChallenge>() {

			@Override
			public int compare(RDNAChallenge challenge1, RDNAChallenge challenge2) {
				return challenge1.index - challenge2.index;
			}
		}; 

		static Comparator<RDNAChallenge> RDNASubChallengeIndexComparator = new Comparator<RDNA.RDNAChallenge>() {

			@Override
			public int compare(RDNAChallenge challenge1, RDNAChallenge challenge2) {
				return challenge1.subChallengeIndex - challenge2.subChallengeIndex;
			}
		}; 
	}

	public static class RDNAChallengeStatus{
		public String message;
		public RDNAChallengeStatusCode statusCode;
		public RDNAChallengeOpMode challengeOperation;

		/**
		 * @brief RDNAChallengeStatus - Class containing status of challenge request.
		 * @param message             - Success or failure message if any.
		 * @param statusCode          - Enum representing the status of challenge. 
		 */
		public RDNAChallengeStatus(String message,RDNAChallengeStatusCode statusCode,RDNAChallengeOpMode challengeOperation){
			this.message = message;
			this.statusCode = statusCode;
			this.challengeOperation = challengeOperation;
		}
	}

	public static enum RDNAChallengeType{
		RDNA_PROMPT_BOOLEAN (0),           /* Prompt, which is like a check box which can be either true or false, e.g is device permanent */
		RDNA_PROMPT_ONE_WAY (1),           /* Prompt for which user is not expected any data to be shown, e.g passwords.  */
		RDNA_PROMPT_TWO_WAY(2);   /* Prompt for which user is expecting any or some data to be shown, e.g secret question and answer */

		public final int intValue;

		private RDNAChallengeType(int val) {
			this.intValue = val;
		}
	}

	public static enum RDNAChallengeStatusCode{
		RDNA_CHLNG_STATUS_SUCCESS,                               /* Sucess challenge                                   */
		RDNA_CHLNG_STATUS_NO_SUCH_USER,                          /* No such user exists.                               */
		RDNA_CHLNG_STATUS_USER_SUSPENDED,                        /* All attempts exhausted.User is suspended           */
		RDNA_CHLNG_STATUS_USER_BLOCKED,                          /* All attempts exhausted.User is blocked             */
		RDNA_CHLNG_STATUS_USER_ALREADY_ACTIVATED,                /* The user is already activated.Please login again   */
		RDNA_CHLNG_STATUS_INVALID_ACT_CODE,                      /* Invalid activation code                            */
		RDNA_CHLNG_STATUS_UPDATE_CHALLENGES_FAILED,              /* Failed to update credentials                       */
		RDNA_CHLNG_STATUS_CHALLENGE_RESPONSE_VALIDATION_FAILED,  /* Failed to Validate previous challenges             */
		RDNA_CHLNG_STATUS_DEVICE_VALIDATION_FAILED,              /* Device validation failed                           */
		RDNA_CHLNG_STATUS_INVALID_CHALLENGE_LIST,                /* Invalid challenge list sent for the state          */
		RDNA_CHLNG_STATUS_INTERNAL_SERVER_ERROR,                 /* Internal server error occured                      */
		RDNA_CHLNG_STATUS_UNKNOWN_ERROR;                          /* Unknown error occured while updating / validaating challenes*/
	}

	public static enum RDNAChallengeOpMode{
		RDNA_CHALLENGE_OP_VERIFY,
		RDNA_CHALLENGE_OP_SET;
	}

	public static enum RDNADeviceStatus{
		RDNA_DEVSTATUS_ACTIVE(0),
		RDNA_DEVSTATUS_UPDATE(1),
		RDNA_DEVSTATUS_DELETE(2),
		RDNA_DEVSTATUS_BLOCKED(3),     // - For Future use
		RDNA_DEVSTATUS_SUSPEND(4);     // - For Future use
		
		private int intValue;
		
		private RDNADeviceStatus(int intValue)
		{
			this.intValue = intValue;
		}
	}
	
	public static enum RDNADeviceBinding{
		RDNA_PERMENANT(0),
		RDNA_TEMPORARY(1);

		private int intValue;

		private RDNADeviceBinding(int intValue)
		{
			this.intValue = intValue;
		}

	}
	
	
	
}
